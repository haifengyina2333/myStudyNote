<?php
echo '该功能暂未开放';
echo '<br>';
echo '网页在 3S 后自动回到主页';
header('Refresh: 3 ; url = http://localhost:3000/php_work/index.php');

                   

