<?php
     setcookie('php_usernumber','',time() -1 ,'../');
     setcookie('php_username','',time() -1 ,'../');
     setcookie('php_password', '', time() -1, '../');
     header('location:../index.php');

   